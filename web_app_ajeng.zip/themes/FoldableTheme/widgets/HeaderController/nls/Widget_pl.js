// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/nls/strings":{_widgetLabel:"Kontroler nag\u0142\u00f3wka",signin:"Zaloguj",signout:"Wyloguj",about:"Informacje o",signInTo:"Zaloguj si\u0119 do",cantSignOutTip:"Funkcja nie ma zastosowania w widoku podgl\u0105du.",more:"wi\u0119cej",_localized:{}}});