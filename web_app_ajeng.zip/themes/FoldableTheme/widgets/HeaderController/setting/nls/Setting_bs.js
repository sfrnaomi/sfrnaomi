// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/setting/nls/strings":{group:"Naziv",openAll:"Otvori sve u jednoj plo\u010di",dropDown:"Prika\u017ei u padaju\u0107em izborniku",noGroup:"Widget za grupu nije postavljen.",groupSetLabel:"Postavi svojstva grupe widgeta",_localized:{}}});